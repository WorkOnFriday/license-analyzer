/**
 * lgpl2p1OrLater: Test for our License Analyzer
 * Copyright (C) 2021 WorkOnFriday
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

package lgpl2p1OrLater;

import dp2.Dp2PriStm;

public class lgpl2p1OrLater {
    public static void main(String[] args) {
        Dp2PriStm dp2 = new Dp2PriStm();
        dp2.priStm();
    }
}
