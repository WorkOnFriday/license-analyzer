public class Pri {
    public int prStm() {
        System.out.println("Business is business.");
        return 1;
    }
}
