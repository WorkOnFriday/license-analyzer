package dp2;

public class Dp2PriStm {

    public void priStm() {
        System.out.println("There is no royal road to learning.");
    }

    public static void main(String[] args) {
	// write your code here
    }
}
