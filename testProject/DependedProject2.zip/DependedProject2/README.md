使用EUPL-1.1许可证

许可证存在于1.根目录下License.txt文件 2. /src/META-INF下License.txt文件。

在META-INF目录中放置License.txt文件，可以让其打包为jar时仍然在jar中存在/META-INF/License.txt，暂未找到其他能在jar包中放入License.txt的方式。