package apache2;

import pri.PriInt;
import pri.PriStat;

public class Apache2 {
    public static void main(String[] args) {
        PriInt pi = new PriInt();
        pi.priInt();
        PriStat ps = new PriStat();
        ps.priStat();
    }
}
