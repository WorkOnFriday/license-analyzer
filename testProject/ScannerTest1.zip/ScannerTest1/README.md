在lib文件夹中放入DependedProject.jar依赖，该jar包提供pri包，使用GPL-2.0-only许可证。

主项目使用GPL-3.0-only许可证，位于根目录下License.txt文件。

使用依赖的配置在ScannerTest1.iml中（由idea生成，作用于idea开发的项目）

对此项目应能检测出其GPL-3.0-only许可证与其依赖包使用的GPL-2.0-only冲突。