package work.gpl3;

import pri.PriStat;
import pri.PriInt;

public class Gpl3 {
    public static void main(String[] args) {
        PriInt pi = new PriInt();
        pi.priInt();
        PriStat ps = new PriStat();
        ps.priStat();
    }
}
