package work;

import pri.PriStat;
import pri.PriInt;

public class Main {

    public static void main(String[] args) {
        // write your code here
        PriInt pi = new PriInt();
        pi.priInt();
        PriStat ps = new PriStat();
        ps.priStat();
    }
}
