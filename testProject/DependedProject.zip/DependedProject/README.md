使用GPL-2.0-only许可证

许可证存在于1.根目录下LICENSE文件 2. /src/META-INF下LICENSE文件。

在META-INF目录中放置LICENSE文件，可以让其打包为jar时仍然在jar中存在/META-INF/LICENSE，暂未找到其他能在jar包中放入LICENSE的方式。