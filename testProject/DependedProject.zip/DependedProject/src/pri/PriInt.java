package pri;

public class PriInt {
    public void priInt() {
        System.out.println("1");
    }
}
