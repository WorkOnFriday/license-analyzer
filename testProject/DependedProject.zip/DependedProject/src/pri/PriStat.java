package pri;

public class PriStat {
    public void priStat() {
        System.out.println("Bad times make a good man.");
    }
}
