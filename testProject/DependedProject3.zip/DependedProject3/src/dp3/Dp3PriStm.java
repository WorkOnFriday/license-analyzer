package dp3;

public class Dp3PriStm {

    public void priStm() {
        System.out.println("Life is real, life is earnest.");
    }

    public static void main(String[] args) {
	// write your code here
    }
}
